task.logmsg("DEBUG","Test Override Add Hook");
work.removeAllAttributes();
work.setProperty(Packages.com.ibm.di.dispatcher.Defs.CACHE_CONNECTORS, "false");
work.setProperty(Packages.com.ibm.di.dispatcher.Defs.STATUSCODE, new Packages.java.lang.Integer(Packages.com.ibm.itim.remoteservices.provider.Status.SUCCESSFUL));

