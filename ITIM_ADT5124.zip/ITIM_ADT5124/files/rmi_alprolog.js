// Import ITDI packages
importPackage(Packages.com.ibm.di);

var adapterVersion = "%%ADAPTER_VERSION%%";
task.logmsg("INFO","Adapter Version - %%ADAPTER_VERSION%%");

// Read AL parameters

// ITIM Account Objectclass
var gITIMAccountObjectclass = "%%ACCOUNT_CLASS%%";


