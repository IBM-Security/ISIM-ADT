function initStatusCode() {
    // Init status code to successful
    work.setProperty(Packages.com.ibm.di.dispatcher.Defs.STATUSCODE, new Packages.java.lang.Integer(
        Packages.com.ibm.itim.remoteservices.provider.Status.SUCCESSFUL));
}

function setStatusUnSuccessful() {
    work.setProperty(Packages.com.ibm.di.dispatcher.Defs.STATUSCODE, new Packages.java.lang.Integer(
        Packages.com.ibm.itim.remoteservices.provider.Status.UNSUCCESSFUL));
}

function processError() {
    work.removeAllAttributes();

    work.setProperty(Packages.com.ibm.di.dispatcher.Defs.STATUSCODE, 
        new Packages.java.lang.Integer(Packages.com.ibm.itim.remoteservices.provider.Status.UNSUCCESSFUL));

    if( error.getString("class") == "javax.naming.CommunicationException")
    {
        work.setProperty(Packages.com.ibm.di.dispatcher.Defs.REASONCODE, 
            new Packages.java.lang.Integer(Packages.com.ibm.itim.remoteservices.provider.Reason.COMMUNICATION_ERROR));
        work.setProperty(Packages.com.ibm.di.dispatcher.Defs.REASON_MESSAGE, 
            Packages.com.ibm.di.dispatcher.DispatcherReasonMessage.CONNECTOR_CONNECTION_ERROR);

    }
    else if( error.getString("class") == "javax.naming.AuthenticationException")
    {
        work.setProperty(Packages.com.ibm.di.dispatcher.Defs.REASONCODE, 
            new Packages.java.lang.Integer(Packages.com.ibm.itim.remoteservices.provider.Reason.AUTHENTICATION_ERROR));
        work.setProperty(Packages.com.ibm.di.dispatcher.Defs.REASON_MESSAGE, 
            Packages.com.ibm.di.dispatcher.DispatcherReasonMessage.ADAPTER_INVALID_LOGIN_CREDENTIALS);
    }
    else if(error.getString("class") == "javax.naming.NameNotFoundException")
    {
        work.setProperty(Packages.com.ibm.di.dispatcher.Defs.REASONCODE, 
            new Packages.java.lang.Integer(Packages.com.ibm.itim.remoteservices.provider.Reason.NAME_NOT_FOUND_ERROR));
        work.setProperty(Packages.com.ibm.di.dispatcher.Defs.REASON_MESSAGE,getErrorReasonMessage());
    }
    else
    {
        work.setProperty(Packages.com.ibm.di.dispatcher.Defs.REASONCODE, 
            new Packages.java.lang.Integer(Packages.com.ibm.itim.remoteservices.provider.Reason.PROCESSING_ERROR));
        work.setProperty(Packages.com.ibm.di.dispatcher.Defs.REASON_MESSAGE,getErrorReasonMessage());
    }

    var v = new Packages.java.util.Vector();
    v.add(gOperationType + " Error: " + error.toString());
    work.setProperty(Packages.com.ibm.di.dispatcher.Defs.REASON_MESSAGE_ARGS, v);

    var e = new Packages.com.ibm.di.exception.ITDIAgentException(gOperationType + " Error");
    e.setEntry(work);
    task.logmsg("DEBUG", "Process Error: Throwing ITDI Exception");
    system.dumpEntry(work);
    throw e;
}

function getErrorReasonMessage() {
    var rmsg = "";
    if (gOperationType == "add") 
        rmsg = Packages.com.ibm.di.dispatcher.DispatcherReasonMessage.ADAPTER_ADD_FAILED;
    else if (gOperationType == "modify") 
        rmsg = Packages.com.ibm.di.dispatcher.DispatcherReasonMessage.ADAPTER_MOD_FAILED;
    else if (gOperationType == "delete") 
        rmsg = Packages.com.ibm.di.dispatcher.DispatcherReasonMessage.ADAPTER_DEL_FAILED;
    else if (gOperationType == "suspend") 
       rmsg = Packages.com.ibm.di.dispatcher.DispatcherReasonMessage.ADAPTER_SUSPEND_FAILED;
    else if (gOperationType == "restore") 
        rmsg = Packages.com.ibm.di.dispatcher.DispatcherReasonMessage.ADAPTER_RESTORE_FAILED;
    else if (gOperationType == "changepassword") 
        rmsg = Packages.com.ibm.di.dispatcher.DispatcherReasonMessage.ADAPTER_MOD_FAILED;
    else if (gOperationType == "search") 
        rmsg = Packages.com.ibm.di.dispatcher.DispatcherReasonMessage.ADAPTER_SRCH_FAILED;
    else task.logmsg("DEBUG", "getErrorReasonMessage: Invalid operation type " + gOperationType);

    task.logmsg("DEBUG","getErrorReasonMessage: ReasonMessage: " + rmsg);
    return rmsg;
}
