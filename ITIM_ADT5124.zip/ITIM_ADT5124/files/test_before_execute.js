task.logmsg("DEBUG","Test Before Execute Hook");
work.removeAllAttributes();
work.setProperty(Packages.com.ibm.di.dispatcher.Defs.STATUSCODE, new Packages.java.lang.Integer(
    Packages.com.ibm.itim.remoteservices.provider.Status.SUCCESSFUL));

