// get UID for DN
ret.value = "eruid=" + conn.getString("uid");