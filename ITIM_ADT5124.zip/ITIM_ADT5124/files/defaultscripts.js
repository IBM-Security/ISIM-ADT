ret.value = "eruid=" + conn.getString("uid");
ret.value = "uid=" + work.getString("eruid") + "," + thisConnector.getConnectorParam("ldapSearchBase");
ret.value = gITIMAccountObjectclass;

