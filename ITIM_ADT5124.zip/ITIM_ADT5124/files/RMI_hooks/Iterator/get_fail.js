task.logmsg("DEBUG","Search Fail Hook");

work.removeAllAttributes();
if( error.getString("class") != "com.ibm.di.exception.ITDIAgentException") {
    work.setProperty(Packages.com.ibm.di.dispatcher.Defs.STATUSCODE, new Packages.java.lang.Integer(
        Packages.com.ibm.itim.remoteservices.provider.Status.UNSUCCESSFUL));

    work.setProperty(Packages.com.ibm.di.dispatcher.Defs.REASONCODE, new Packages.java.lang.Integer(
        Packages.com.ibm.itim.remoteservices.provider.Reason.PROCESSING_ERROR));

    work.setProperty(Packages.com.ibm.di.dispatcher.Defs.REASON_MESSAGE, 
        Packages.com.ibm.di.dispatcher.DispatcherReasonMessage.ADAPTER_SRCH_FAILED);

    var v = new Packages.java.util.Vector();
    v.add("Update Unsuccesful : " + error.toString());
    work.setProperty(Packages.com.ibm.di.dispatcher.Defs.REASON_MESSAGE_ARGS, v);

    task.logmsg("ERROR", "[Iterator Error] Search Entry Unsuccessful " + error.toString());

    var e = new Packages.com.ibm.di.exception.ITDIAgentException("");
    e.setEntry(work);
    throw e;
}



