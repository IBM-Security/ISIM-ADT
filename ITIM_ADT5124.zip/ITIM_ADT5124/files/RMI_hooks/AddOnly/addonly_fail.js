task.logmsg("DEBUG","AddOnly Fail Hook");
processError();
