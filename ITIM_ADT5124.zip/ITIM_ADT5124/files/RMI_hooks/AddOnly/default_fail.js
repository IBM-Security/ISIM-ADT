task.logmsg("DEBUG","Default Fail Hook");

processError();
