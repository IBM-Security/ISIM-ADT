task.logmsg("DEBUG","Initialize Fail Hook");
var work = system.newEntry();

processError();

