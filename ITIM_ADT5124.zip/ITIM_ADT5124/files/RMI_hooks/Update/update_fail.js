task.logmsg("DEBUG","Update Fail Hook");

processError();
