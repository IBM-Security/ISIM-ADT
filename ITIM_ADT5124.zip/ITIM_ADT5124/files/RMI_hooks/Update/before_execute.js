task.logmsg("DEBUG","Modify Before Excute Hook");

work.setOp(work.OP_MOD);

// Set the erAccountStatus attribute based on the operation type
if(gOperationType.indexOf("suspend") >= 0) {
    task.logmsg("DEBUG", "[Before Execute] Operation is suspend");
    work.setAttribute("erAccountStatus","1");
}
else if(gOperationType.indexOf("restore") >= 0) {
    task.logmsg("DEBUG","[Before Execute] Operation is Restore");
    work.setAttribute("erAccountStatus","0");
}
else if(gOperationType.indexOf("changePassword") >= 0) {
    task.logmsg("DEBUG","[Before Execute] Operation is Change Password");
}
else {
    task.logmsg("DEBUG","[Before Execute] Operation is modify");
}
