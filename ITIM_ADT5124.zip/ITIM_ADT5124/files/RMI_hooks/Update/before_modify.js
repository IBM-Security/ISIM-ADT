task.logmsg("DEBUG","Before Modify Hook");

// The following will set the proper operation code for attribute values when it is a 
// replace operation. The ITIM service provider sets the attribute value operation to
// AttributeValue.AV_UNDEFINED for attribute values being replaced on a modify operation.
// If the value is a replace (AV_UNDEFINED) then store it as a straight string rather
// then an AttributeValue object. Some connectors do not like an AV_UNDEFINED code when
// the attribute value is an AttributeValue object but are ok with a string value and
// no operation code.


// Get the names of all attributes
var attrnames = conn.getAttributeNames();

// Process each attribute
for ( i = 0; i < attrnames.length; i++ ) {
    // Get this attr from the conn entry
    var attr = conn.getAttribute(attrnames[i]);

    // Remove the current attribute (we will replace it with a completed version)
    conn.removeAttribute(attr.getName());

    // Create a new attribute
    var newattr = conn.newAttribute(attr.getName());

    // process each value of this attribute
    for (j=0;j<attr.size();j++ ) {
        // add the value to the new copy of the attr
        newattr.addValue(attr.getValue(j));

        // If the ITIM value operation is not AV_UNDEFINED (-1) then use the
        // AttributeValue object created in ITIM, it would have an op code or AV_ADD or AV_DELETE
        // otherwise, leave the value as a string (returned from attr.getValue(j) above)
        if( attr.getValueOper(j) != -1) {
            newattr.setValueOper( j,attr.getValueOper(j) );
        }
    }
}

