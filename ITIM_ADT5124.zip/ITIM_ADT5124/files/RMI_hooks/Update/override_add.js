task.logmsg("DEBUG","Modify Override Add Hook");
var entryDN = work.getString("entryDN");
work.removeAllAttributes();
work.setProperty(Packages.com.ibm.di.dispatcher.Defs.STATUSCODE,
    Packages.com.ibm.itim.remoteservices.provider.Status.UNSUCCESSFUL);

work.setProperty(Packages.com.ibm.di.dispatcher.Defs.REASONCODE,
    Packages.com.ibm.itim.remoteservices.provider.Reason.NAME_NOT_FOUND_ERROR);

work.setProperty(Packages.com.ibm.di.dispatcher.Defs.REASON_MESSAGE,
    Packages.com.ibm.di.dispatcher.DispatcherReasonMessage.ADAPTER_MOD_FAILED);

var v = new Packages.java.util.Vector();
v.add("Entry not Found Error.");
work.setProperty(Packages.com.ibm.di.dispatcher.Defs.REASON_MESSAGE_ARGS, v);

task.logmsg("ERROR","User Entry not found");

var e = new Packages.com.ibm.di.exception.ITDIAgentException(entryDN + ": Not Found in managed resource");
e.setEntry(work);
throw e;

