task.logmsg("DEBUG","Delete OK Hook");
work.removeAllAttributes();
work.setProperty(Packages.com.ibm.di.dispatcher.Defs.STATUSCODE, new Packages.java.lang.Integer(
    Packages.com.ibm.itim.remoteservices.provider.Status.SUCCESSFUL));

