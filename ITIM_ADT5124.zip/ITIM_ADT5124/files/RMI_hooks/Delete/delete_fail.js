task.logmsg("DEBUG","Delete Fail Hook");
processError();
